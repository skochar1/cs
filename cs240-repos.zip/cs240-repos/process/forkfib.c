/** Implement the forkfib program in this file. */

int main(int argc, char** argv) {
  return 0;
}
